# Module: Dịch vụ – Employer branding (採用ブランディング)

| Step | File | Thao tác |
|------|------|----------|
| 01 | `step-01-tu-dashboard.png` | Dashboard |
| 02 | `step-02-sidebar-vao-dich-vu.png` | Sidebar **採用ブランディング** |
| 03 | `step-03-trang-dich-vu-tong-quan.png` | `/business/saiyo` – LP / Ads / Event / Company profile |
| 04 | `step-04-tuy-chon-landing-page.png` | **既存LPを作成** / **サービスを依頼** |
