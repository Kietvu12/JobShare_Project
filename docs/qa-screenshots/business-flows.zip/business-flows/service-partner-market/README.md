# Module: Dịch vụ – Partner market (採用パートナーマーケット)

| Step | File | Thao tác |
|------|------|----------|
| 01 | `step-01-tu-dashboard.png` | Dashboard |
| 02 | `step-02-sidebar-vao-dich-vu.png` | Sidebar **採用パートナーマーケット** |
| 03 | `step-03-trang-dich-vu-tong-quan.png` | `/business/candidate-sharing` |
| 04 | `step-04-nhan-dang-jd-market.png` | **採用パートナーマーケットにJD掲載** |
