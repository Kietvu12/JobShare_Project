# Module: Dịch vụ – Direct Scout (ダイレクトスカウト)

| Step | File | Thao tác |
|------|------|----------|
| 01 | `step-01-tu-dashboard.png` | Dashboard – 4 dịch vụ |
| 02 | `step-02-sidebar-vao-dich-vu.png` | (Khi click được) Sidebar **ダイレクトスカウト** |
| 03 | `step-03-trang-dich-vu-tong-quan.png` | `/business/scout/direct` – gói credit + **スカウトを開始** |
| 04 | `step-04-nhan-scout-start.png` | Nút bắt đầu scout |
| 05 | `step-05-man-hinh-tim-ung-vien.png` | Màn hình tìm / unlock ứng viên |
