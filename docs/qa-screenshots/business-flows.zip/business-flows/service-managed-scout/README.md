# Module: Dịch vụ – Scout ủy thác (おまかせスカウト)

| Step | File | Thao tác |
|------|------|----------|
| 01 | `step-01-tu-dashboard.png` | Dashboard |
| 02 | `step-02-sidebar-vao-dich-vu.png` | Sidebar **おまかせスカウト** |
| 03 | `step-03-trang-dich-vu-tong-quan.png` | `/business/scout/managed` |
| 04 | `step-04-nhan-yeu-cau-scout.png` | **スカウトを依頼** / luồng gửi yêu cầu WS |
